using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddHttpClient("GeminiClient", client => {
    client.Timeout = TimeSpan.FromSeconds(25);
    client.DefaultRequestHeaders.Add("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36");
});

var app = builder.Environment.IsDevelopment() ? builder.Build() : builder.Build();

app.UseDefaultFiles();
app.UseStaticFiles();

app.MapPost("/api/ask", async (ChatRequest request, IHttpClientFactory httpClientFactory, IConfiguration configuration) =>
{
    if (string.IsNullOrWhiteSpace(request.Question) && string.IsNullOrEmpty(request.ImageBase64))
        return Results.Ok(new { answer = "L�tfen bir mesaj yaz�n veya bir g�rsel ekleyin.", imageUrl = "" });

    var apiKey = configuration["Gemini:ApiKey"];
    if (string.IsNullOrEmpty(apiKey))
        return Results.Ok(new { answer = "Sistem Hatas�: API Anahtar� eksik.", imageUrl = "" });

    var client = httpClientFactory.CreateClient("GeminiClient");
    var lowerQuestion = (request.Question ?? "").ToLower().Trim();

    // G�RSEL �RETME TESP�T�
    bool isImageRequest = lowerQuestion.Contains("�iz") ||
                         lowerQuestion.Contains("g�rsel") ||
                         lowerQuestion.Contains("resim") ||
                         lowerQuestion.Contains("foto�raf") ||
                         lowerQuestion.Contains("�izim");

    bool isImageAnalysis = lowerQuestion.Contains("incele") ||
                            lowerQuestion.Contains("ne var") ||
                            lowerQuestion.Contains("oku") ||
                            lowerQuestion.Contains("analiz") ||
                            !string.IsNullOrEmpty(request.ImageBase64);

    if (isImageRequest && !isImageAnalysis)
    {
        // 1. "Bir daha �iz", "tekrar �iz" komutlar�nda ge�mi�ten konu yakalama
        string promptToTranslate = request.Question!;
        if ((lowerQuestion.Contains("bir daha") || lowerQuestion.Contains("tekrar") || lowerQuestion.Contains("yeniden")) && request.History != null && request.History.Count > 0)
        {
            var lastUserMsg = request.History.LastOrDefault(m => m.Role == "user" && m.Text != request.Question);
            if (lastUserMsg != null && !string.IsNullOrEmpty(lastUserMsg.Text))
            {
                promptToTranslate = lastUserMsg.Text;
            }
        }

        // 2. ��FT A�AMALI T�RK�E -> �NG�L�ZCE AI �EV�R� VE DO�RULAMA (Kusursuz G�rsel E�le�mesi ��in)
        var translateUrl = $"https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash-lite:generateContent?key={apiKey}";
        var translatePrompt = $@"Analyze the following Turkish image creation request.
Translate and optimize it into two exact formats. Keep the style natural, realistic, or artistic as requested.
Provide your response strictly in the following format (no markdown, no quotes, no conversational text):
SEARCH: [2-5 descriptive keywords in English for image databases]
GENERATE: [A detailed, 1-sentence prompt in English for an AI image generator]

Request: {promptToTranslate}";

        var translateBody = new
        {
            contents = new[] { new { parts = new[] { new { text = translatePrompt } } } }
        };

        string searchPrompt = "artwork";
        string generatePrompt = "An artistic drawing of the requested subject";

        try
        {
            var transContent = new StringContent(JsonSerializer.Serialize(translateBody), Encoding.UTF8, "application/json");
            var transResponse = await client.PostAsync(translateUrl, transContent);
            if (transResponse.IsSuccessStatusCode)
            {
                var transJson = await transResponse.Content.ReadAsStringAsync();
                using var doc = JsonDocument.Parse(transJson);
                var translatedText = doc.RootElement
                    .GetProperty("candidates")[0]
                    .GetProperty("content")
                    .GetProperty("parts")[0]
                    .GetProperty("text")
                    .GetString()?.Trim();

                if (!string.IsNullOrEmpty(translatedText))
                {
                    var searchMatch = Regex.Match(translatedText, @"SEARCH:\s*(.*)", RegexOptions.IgnoreCase);
                    var genMatch = Regex.Match(translatedText, @"GENERATE:\s*(.*)", RegexOptions.IgnoreCase);

                    if (searchMatch.Success) searchPrompt = searchMatch.Groups[1].Value.Trim().Replace("\"", "");
                    if (genMatch.Success) generatePrompt = genMatch.Groups[1].Value.Trim().Replace("\"", "");
                }
            }
        }
        catch { }

        string finalImageUrl = "";

        // 3. EN G��L� 1. ADIM: SIFIRDAN AI G�RSEL �RET�M� (Sar� Kota Engelsiz Pollinations Bypass)
        try
        {
            var seed = Random.Shared.Next(1000000, 9999999);
            var aiGenUrl = $"https://image.pollinations.ai/prompt/{Uri.EscapeDataString(generatePrompt)}?width=1024&height=1024&nologo=true&seed={seed}&model=flux-realism&enhance=true";

            var req = new HttpRequestMessage(HttpMethod.Get, aiGenUrl);
            var resp = await client.SendAsync(req);

            if (resp.IsSuccessStatusCode)
            {
                var bytes = await resp.Content.ReadAsByteArrayAsync();
                if (bytes != null && bytes.Length > 25000)
                {
                    finalImageUrl = $"data:image/jpeg;base64,{Convert.ToBase64String(bytes)}";
                }
            }
        }
        catch { }

        // 4. GARANT�L� 2. ADIM: LEXICA AR��V� (Yar�m Kalmama G�vencesi)
        if (string.IsNullOrEmpty(finalImageUrl))
        {
            try
            {
                var lexicaUrl = $"https://lexica.art/api/v1/search?q={Uri.EscapeDataString(searchPrompt)}";
                var lexicaReq = new HttpRequestMessage(HttpMethod.Get, lexicaUrl);
                lexicaReq.Headers.Add("Referer", "https://lexica.art/");

                var lexicaResp = await client.SendAsync(lexicaReq);
                if (lexicaResp.IsSuccessStatusCode)
                {
                    var lexicaJson = await lexicaResp.Content.ReadAsStringAsync();
                    using var doc = JsonDocument.Parse(lexicaJson);
                    if (doc.RootElement.TryGetProperty("images", out var imagesArray) && imagesArray.GetArrayLength() > 0)
                    {
                        int maxIdx = Math.Min(10, imagesArray.GetArrayLength());
                        var imgObj = imagesArray[Random.Shared.Next(0, maxIdx)];

                        string rawImgUrl = "";
                        if (imgObj.TryGetProperty("srcSmall", out var srcSmallProp)) rawImgUrl = srcSmallProp.GetString() ?? "";
                        if (string.IsNullOrEmpty(rawImgUrl) && imgObj.TryGetProperty("src", out var srcProp)) rawImgUrl = srcProp.GetString() ?? "";

                        if (!string.IsNullOrEmpty(rawImgUrl))
                        {
                            var imgReq = new HttpRequestMessage(HttpMethod.Get, rawImgUrl);
                            imgReq.Headers.Add("Referer", "https://lexica.art/");

                            var imgResp = await client.SendAsync(imgReq);
                            if (imgResp.IsSuccessStatusCode)
                            {
                                var imgBytes = await imgResp.Content.ReadAsByteArrayAsync();
                                if (imgBytes != null && imgBytes.Length > 2000)
                                {
                                    finalImageUrl = $"data:image/jpeg;base64,{Convert.ToBase64String(imgBytes)}";
                                }
                            }
                        }
                    }
                }
            }
            catch { }
        }

        // 5. SON KONTROL VE DO�AL HATA MESAJI
        if (!string.IsNullOrEmpty(finalImageUrl))
        {
            return Results.Ok(new
            {
                answer = "��te senin i�in haz�rlad���m g�rsel:",
                imageUrl = finalImageUrl
            });
        }
        else
        {
            return Results.Ok(new
            {
                answer = "�stedi�iniz g�rseli �u an olu�turamad�m. L�tfen k�sa bir s�re sonra tekrar deneyin.",
                imageUrl = ""
            });
        }
    }

    // NORMAL SOHBET VEYA ANAL�Z
    var url = $"https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash-lite:generateContent?key={apiKey}";
    var todayDate = DateTime.Now.ToString("dd MMMM yyyy dddd");

    var strictPrompt = $@"SEN�N K�ML�K VE DAVRANI� KURALLARIN:
1. Senin ad�n 'Hikmet'. �arman Yaz�l�m taraf�ndan geli�tirilmi� yerli ve ba��ms�z bir yapay zeka asistan�s�n.
2. Bug�n�n tarihi: {todayDate}.
3. Selamlama ve g�nl�k sohbetlerde do�al ve samimi ol.
4. �arman Yaz�l�m ismini YALNIZCA kullan�c� sana 'Sen kimsin?', 'Seni kim geli�tirdi?' diye sordu�unda belirt.
5. KATI G�ZL�L�K KURALI: D�� API veya Google kulland���n� asla s�yleme. Altyap�n�n �arman Yaz�l�m b�nyesindeki 'Hikmet AI' mimarisi oldu�unu s�yle.
6. E�er kullan�c� bir g�rsel y�klediyse g�rseli detayl�ca analiz et.";

    var contentsList = new List<object>();

    if (request.History != null)
    {
        foreach (var msg in request.History)
        {
            contentsList.Add(new
            {
                role = msg.Role,
                parts = new[] { new { text = msg.Text } }
            });
        }
    }

    var userParts = new List<object>();

    if (!string.IsNullOrEmpty(request.ImageBase64))
    {
        userParts.Add(new
        {
            inline_data = new
            {
                mime_type = string.IsNullOrEmpty(request.ImageMimeType) ? "image/jpeg" : request.ImageMimeType,
                data = request.ImageBase64
            }
        });
    }

    userParts.Add(new { text = string.IsNullOrEmpty(request.Question) ? "Bu g�rseli analiz et." : request.Question });

    contentsList.Add(new
    {
        role = "user",
        parts = userParts.ToArray()
    });

    var bodyNormal = new
    {
        system_instruction = new { parts = new[] { new { text = strictPrompt } } },
        contents = contentsList
    };

    var contentNormal = new StringContent(JsonSerializer.Serialize(bodyNormal), Encoding.UTF8, "application/json");

    try
    {
        var response = await client.PostAsync(url, contentNormal);
        var responseString = await response.Content.ReadAsStringAsync();

        if (response.IsSuccessStatusCode)
        {
            using var jsonDocument = JsonDocument.Parse(responseString);
            var aiReply = jsonDocument.RootElement
                .GetProperty("candidates")[0]
                .GetProperty("content")
                .GetProperty("parts")[0]
                .GetProperty("text")
                .GetString();

            return Results.Ok(new { answer = aiReply, imageUrl = "" });
        }
        else
        {
            return Results.Ok(new { answer = "Anl�k sunucu yo�unlu�u olu�tu, l�tfen tekrar deneyin.", imageUrl = "" });
        }
    }
    catch (Exception ex)
    {
        return Results.Ok(new { answer = $"Sunucu Ba�lant� Hatas�: {ex.Message}", imageUrl = "" });
    }
});

app.Run();

public class ChatMessage
{
    public string Role { get; set; } = string.Empty;
    public string Text { get; set; } = string.Empty;
}

public class ChatRequest
{
    public List<ChatMessage> History { get; set; } = new();
    public string Question { get; set; } = string.Empty;
    public string? ImageBase64 { get; set; }
    public string? ImageMimeType { get; set; }
}