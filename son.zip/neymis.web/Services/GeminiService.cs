﻿using System;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace HikmetAI.Services
{
    public class GeminiService
    {
        private readonly HttpClient _httpClient;
        private readonly string _apiKey = "AQ.Ab8RN6INA6HKpOqfiHW9SEqL70wbNk3Sh088z5UPcovrYJNnfQ";

        public GeminiService(HttpClient httpClient)
        {
            _httpClient = httpClient;
            _httpClient.Timeout = TimeSpan.FromSeconds(7);
        }

        public async Task<string> AskQuestionAsync(string userQuestion)
        {
            var currentDate = DateTime.Now.ToString("dd MMMM yyyy dddd");

            string systemInstructionText = $@"Sen Şarman Yazılım tarafından geliştirilen Hikmet AI asistanısın.
Bugünün Tarihi: {currentDate}.

KESİN KURALLAR:
1. 'Senin için derledim', 'Nasıl buldun?', 'Sence yeterli mi?' gibi giriş, selamlama veya soru kapatma cümlelerini KESİNLİKLE KULLANMA.
2. Doğrudan ve net bir şekilde cevaba başla.
3. Yanıt verirken maddeleri, listeleri ve kadroları mutlaka alt alta yaz. Tek paragrafta sıkıştırma.
4. Uzun anlatımlarda metni okunabilir, mantıklı paragraflara böl ve aralarında boş satır bırak.";

            var requestBody = new
            {
                system_instruction = new
                {
                    parts = new[]
                    {
                        new { text = systemInstructionText }
                    }
                },
                contents = new[]
                {
                    new
                    {
                        role = "user",
                        parts = new[]
                        {
                            new { text = userQuestion }
                        }
                    }
                },
                generationConfig = new
                {
                    temperature = 0.2,
                    maxOutputTokens = 1000
                }
            };

            var jsonContent = new StringContent(
                JsonSerializer.Serialize(requestBody),
                Encoding.UTF8,
                "application/json"
            );

            try
            {
                var response = await _httpClient.PostAsync(
                    $"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={_apiKey}",
                    jsonContent
                );

                var responseString = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                {
                    return "Üzgünüm, şu an yanıt üretirken bir sorun oluştu.";
                }

                using var doc = JsonDocument.Parse(responseString);

                var candidates = doc.RootElement.GetProperty("candidates");
                if (candidates.GetArrayLength() > 0)
                {
                    var text = candidates[0]
                        .GetProperty("content")
                        .GetProperty("parts")[0]
                        .GetProperty("text")
                        .GetString();

                    return text;
                }

                return "Yanıt alınamadı.";
            }
            catch (Exception ex)
            {
                return $"Bağlantı hatası oluştu: {ex.Message}";
            }
        }
    }
}